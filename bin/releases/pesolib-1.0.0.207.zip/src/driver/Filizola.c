#include "Filizola.h"
#include "DevicePrivate.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef struct Filizola
{
	int peso;
	char models[48];
	char buffer[16];
} Filizola;


int Filizola_init(Device* _dev)
{
	Filizola* dev = (Filizola*)_dev->data;
	dev->peso = 0;
	strcpy(dev->models, ""); // TODO: add models
	return 1;
}

int Filizola_execute(Device* _dev, const unsigned char* buffer, int size)
{
	Filizola* dev = (Filizola*)_dev->data;
	if(size < 7 || buffer[0] != 0x02 || (buffer[6] != 0x03 && buffer[6] != 0x0D))
		return 0;
	int i, peso = 0, mult = 1;
	for(i = 5; i >= 1; i--)
	{
		if(buffer[i] < '0' || buffer[i] > '9')
			return 0;
		peso += mult * (buffer[i] - '0');
		mult *= 10;
	}
	dev->peso = peso;
	return 7;
}

const char* Filizola_getProperty(Device* _dev, const char* key)
{
	Filizola* dev = (Filizola*)_dev->data;
	if(strcmp("weight", key) == 0)
	{
		sprintf(dev->buffer, "%d", dev->peso);
		return dev->buffer;
	}
	if(strcmp("name", key) == 0)
	{
		strcpy(dev->buffer, "Filizola");
		return dev->buffer;
	}
	if(strcmp("models", key) == 0)
	{
		return dev->models;
	}
	return NULL;
}

int Filizola_makeCmd(Device* _dev, const char* func, const char * data, 
	unsigned char* cmdOut, int bufLen)
{
	//Filizola* dev = (Filizola*)_dev;
	if(strcmp("getweight", func) == 0)
	{
		const unsigned char cmd[] = { 0x05 };
		int bWritten = bufLen;
		if(bWritten > 1)
			bWritten = 1;
		memcpy(cmdOut, cmd, bWritten);
		return bWritten;
	}
	if(strcmp("setprice", func) == 0)
	{
		return 0; // not supported
	}
	return 0;
}

void Filizola_free(Device* _dev)
{
	Filizola* dev = (Filizola*)_dev->data;
	free(dev);
	Device_release(_dev);
}

Device * Device_createFilizola()
{
	Filizola* _dev = (Filizola*)malloc(sizeof(Filizola));
	Device* dev = Device_alloc(_dev);
	dev->init = Filizola_init;
	dev->execute = Filizola_execute;
	dev->getProperty = Filizola_getProperty;
	dev->makeCmd = Filizola_makeCmd;
	dev->free = Filizola_free;
	return dev;
}
