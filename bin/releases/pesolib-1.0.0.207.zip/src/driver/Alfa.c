#include "Alfa.h"
#include "DevicePrivate.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef struct Alpha
{
	int peso;
	char models[48];
	char buffer[24];
} Alpha;


int Alpha_init(Device* _dev)
{
	Alpha* dev = (Alpha*)_dev->data;
	dev->peso = 0;
	strcpy(dev->models, "3101C"); // TODO: add models
	return 1;
}

int Alpha_execute(Device* _dev, const unsigned char* buffer, int size)
{
	Alpha* dev = (Alpha*)_dev->data;
	// PB: 230,50 T: 000,00\r\n
	// PL: 123,45 T: 010,00\r\n
	// **: 230,50 T: 000,00\r\n
	if(size < 22 || buffer[0] != 'P' || buffer[1] != 'L' || buffer[2] != ':' || buffer[3] == '-' || buffer[11] != 'T' 
		|| buffer[12] != ':' || buffer[20] != 0x13 || buffer[21] != 0x10)
		return 0;
	int i, peso = 0, mult = 1;
	unsigned char bff[6];
	memcpy(bff, buffer + 4, 3);
	memcpy(bff, buffer + 8, 2);
	bff[5] = '0';
	for(i = 5; i >= 0; i--)
	{
		if(bff[i] < '0' || bff[i] > '9')
			return 0;
		peso += mult * (bff[i] - '0');
		mult *= 10;
	}
	dev->peso = peso;
	return 22;
}

const char* Alpha_getProperty(Device* _dev, const char* key)
{
	Alpha* dev = (Alpha*)_dev->data;
	if(strcmp("weight", key) == 0)
	{
		sprintf(dev->buffer, "%d", dev->peso);
		return dev->buffer;
	}
	if(strcmp("name", key) == 0)
	{
		strcpy(dev->buffer, "Alpha");
		return dev->buffer;
	}
	if(strcmp("models", key) == 0)
	{
		return dev->models;
	}
	return NULL;
}

int Alpha_makeCmd(Device* _dev, const char* func, const char * data, 
	unsigned char* cmdOut, int bufLen)
{
	//Alpha* dev = (Alpha*)_dev;
	if(strcmp("getweight", func) == 0)
	{
		const unsigned char cmd[] = { '0', '1', 'P', 0x13, 0x10 };
		int bWritten = bufLen;
		if(bWritten > sizeof(cmd))
			bWritten = sizeof(cmd);
		memcpy(cmdOut, cmd, bWritten);
		return bWritten;
	}
	if(strcmp("setprice", func) == 0)
	{
		return 0; // not supported
	}
	return 0;
}

void Alpha_free(Device* _dev)
{
	Alpha* dev = (Alpha*)_dev->data;
	free(dev);
	Device_release(_dev);
}

Device * Device_createAlpha()
{
	Alpha* _dev = (Alpha*)malloc(sizeof(Alpha));
	Device* dev = Device_alloc(_dev);
	dev->init = Alpha_init;
	dev->execute = Alpha_execute;
	dev->getProperty = Alpha_getProperty;
	dev->makeCmd = Alpha_makeCmd;
	dev->free = Alpha_free;
	return dev;
}
