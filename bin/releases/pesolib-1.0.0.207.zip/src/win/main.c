#include <private/Plataforma.h>
#include <windows.h>

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	switch(fdwReason)
	{
	case DLL_PROCESS_ATTACH:
		return PesoLib_inicializa();
	case DLL_PROCESS_DETACH:
		PesoLib_finaliza();
		break;
	}
	return TRUE; // succesful
}
#ifdef DEBUGLIB
#include "PesoLib.h"
#include "CommPort.h"
#include <stdio.h>
#include <windows.h>

int main(int argc, char** argv)
{
	DWORD startTick = GetTickCount();
	int gramas;
	int i, bAval;
	CommPort * comm;
	
	unsigned char cmd[] = { 0x05 };
	unsigned char * bytes;
	/*
	for(i = 0; i < 1000; i++)
	{
		printf("Conectando\n");
		comm = CommPort_create("COM3");
		printf("Enviando\n");
		if(CommPort_writeEx(comm, cmd, 1, 250))
		{
			printf("Aguardando\n");
			if(CommPort_waitEx(comm, &bAval, 500))
			{
				printf("Recebendo %d\n", bAval);
				bytes = (unsigned char *)malloc(bAval + 1);
				if(CommPort_readEx(comm, bytes, bAval, 250))
				{
					bytes[bAval] = 0;
					printf("Received: %s\n", (char*)bytes);
				}
				else
				{
					printf("A leitura falhou\n");
				}
				free(bytes);
			}
			else
			{
				printf("A espera falhou\n");
			}
		}
		else
		{
			printf("O envio falhou\n");
		}
		printf("Liberando\n");
		CommPort_free(comm);
		printf("Pronto!\n");
	}*/
	PesoLib_inicializa();
	PesoLib* lib = PesoLib_cria(NULL);
	int evento;
	DWORD endTick;
	while((evento = PesoLib_aguardaEvento(lib)) != Evento_Cancelado)
	{
		switch(evento)
		{
		case Evento_Conectado:
			endTick = GetTickCount() - startTick;
			printf("Balanca conectada\n");
			printf("Tempo: %.3lf s\n", endTick / 1000.0);
			PesoLib_solicitaPeso(lib, 5.00f);
			continue;
		case Evento_Desconectado:
			printf("Balanca desconectada\n");
			startTick = GetTickCount();
			Sleep(5000);
			continue;
		}
		gramas = PesoLib_getUltimoPeso(lib);
		printf("Peso recebido: %.3f Kg\n", gramas / 1000.0);
		//_PesoLib_cancela(lib);
		//printf("Configuracao: %s\n", _PesoLib_getConfiguracao(lib));
	}
	PesoLib_libera(lib);
	PesoLib_finaliza();
	return 0;
}
#endif